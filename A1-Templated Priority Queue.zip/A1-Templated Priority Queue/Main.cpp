#include "Alberto.h"
#include <iostream>
using namespace std;


void wrapper()
{
    //Integer Stack created
    cout << "Integers on a Queue ->" << endl;
    PriorityQueue<int> myQueue;

    //Pushing integer elements onto stack
    myQueue.push(1);
    cout << "	just pushed +++++" << endl;
    myQueue.push(2);
    cout << "	just pushed +++++" << endl;
    myQueue.push(3);
    cout << "	just pushed +++++" << endl;
    myQueue.push(4);
    cout << "	just pushed +++++" << endl;

    //Printing result
    myQueue.print();

    cout << endl;

    //Popping values off of stack(3, 4)
    cout << "Integers removed on Queue ->" << endl;
    myQueue.pop();
    cout << "		just popped -----" << endl;
    myQueue.pop();
    cout << "		just popped -----" << endl;

    //Print result
    myQueue.print();

    cout << endl;

    //Checks if stack is empty and the current size
    cout << "Is the stack empty? " << myQueue.IsEmpty() << " (1 = True, 0 = False)" << endl;
    cout << "Stack size: " << myQueue.GetSize() << endl;

    cout << endl << endl;

    //Character stack created
    cout << "Characters on a Queue ->" << endl;
    PriorityQueue<char> myQueue2;

    //Pushing character elements on stack
    myQueue2.push('a');
    cout << "	just pushed +++++" << endl;
    myQueue2.push('b');
    cout << "	just pushed +++++" << endl;
    myQueue2.push('c');
    cout << "	just pushed +++++" << endl;
    myQueue2.push('d');
    cout << "	just pushed +++++" << endl;

    //Print result
    myQueue2.print();

    cout << endl;

    //Popping characters off stack(c, and d)
    cout << "Characters removed on Queue ->" << endl;
    myQueue2.pop();
    cout << "		just popped -----" << endl;
    myQueue2.pop();
    cout << "		just popped -----" << endl;

    //Print result
    myQueue2.print();

    cout << endl;

    // Checks if stack is empty and the current size
    cout << "Is the Queue empty? " << myQueue2.IsEmpty() << " (1 = True, 0 = False)" << endl;
    cout << "Queue size: " << myQueue2.GetSize() << endl;

    cout << endl << endl;

    //Creating double elements on Queue
    cout << "Double on a Queue ->" << endl;
    PriorityQueue<double> myQueue3;

    //Pushing double elements on Queue
    myQueue3.push(11.1);
    cout << "	just pushed +++++" << endl;
    myQueue3.push(22.2);
    cout << "	just pushed +++++" << endl;
    myQueue3.push(33.3);
    cout << "	just pushed +++++" << endl;
    myQueue3.push(44.4);
    cout << "	just pushed +++++" << endl;

    //Print result
    myQueue3.print();

    cout << endl;

    //Popping off elements from stack (44.4, and 33.3)
    cout << "Popping off the two back elements on Queue ->" << endl;
    myQueue3.pop();
    cout << "		just popped -----" << endl;
    myQueue3.pop();
    cout << "		just popped -----" << endl;

    //Print result
    myQueue3.print();

    cout << endl;

    // Checks if Queue is empty and the current size
    cout << "Is the Queue empty? " << myQueue3.IsEmpty() << " (1 = True, 0 = False)" << endl;
    cout << "Queue size: " << myQueue3.GetSize() << endl;

    cout << endl << endl;

    //Creating Float elements on Queue
    cout << "Float on a Queue ->" << endl;
    PriorityQueue<float> myQueue4;

    //Pushing double elements on Queue
    myQueue4.push(11.1f);
    cout << "	just pushed +++++" << endl;
    myQueue4.push(22.2f);
    cout << "	just pushed +++++" << endl;
    myQueue4.push(33.3f);
    cout << "	just pushed +++++" << endl;
    myQueue4.push(44.4f);
    cout << "	just pushed +++++" << endl;

    //Print result
    myQueue4.print();

    cout << endl;

    //Popping off elements from stack (44.4, and 33.3)
    cout << "Popping off the two back elements on Queue ->" << endl;
    myQueue4.pop();
    cout << "		just popped -----" << endl;
    myQueue4.pop();
    cout << "		just popped -----" << endl;

    //Print result
    myQueue4.print();

    cout << endl;

    // Checks if Queue is empty and the current size
    cout << "Is the Queue empty? " << myQueue4.IsEmpty() << " (1 = True, 0 = False)" << endl;
    cout << "Queue size: " << myQueue4.GetSize() << endl;

    cout << endl << endl;

    cout << "Short on a Queue ->" << endl;
    PriorityQueue<short> myQueue5;

    //Pushing double elements on Queue
    myQueue5.push(11);
    cout << "	just pushed +++++" << endl;
    myQueue5.push(22);
    cout << "	just pushed +++++" << endl;
    myQueue5.push(33);
    cout << "	just pushed +++++" << endl;
    myQueue5.push(44);
    cout << "	just pushed +++++" << endl;

    //Print result
    myQueue4.print();

    cout << endl;

    //Popping off elements from stack (44.4, and 33.3)
    cout << "Popping off the two back elements on Queue ->" << endl;
    myQueue5.pop();
    cout << "		just popped -----" << endl;
    myQueue5.pop();
    cout << "		just popped -----" << endl;

    //Print result
    myQueue5.print();

    cout << endl;

    // Checks if Queue is empty and the current size
    cout << "Is the Queue empty? " << myQueue5.IsEmpty() << " (1 = True, 0 = False)" << endl;
    cout << "Queue size: " << myQueue5.GetSize() << endl;

    cout << endl << endl;
    //Proving that copy constructor and copy assignment operators work
    //cout << "Proving that copy constructor and copy assignment operators work ->" << endl;
   // uint count = mystack3.GetSize();
    //for (uint i = 0; i < count; ++i)
    //{
        //mystack3.pop();
        //cout << "		just popped -----" << endl;
    //}

    //myQueue3.print();
    //Print queue
   // Print<int>(myQueue);
    //Creating a new stack using another with the same template type as parameter for my copy constructor.
    //Stack<int> secondIntStack = Stack<int>(mystack);
    //cout << "Popping off an element on stack ->" << endl;
    //Pop an element off
    //secondIntStack.pop();
    //Print result
    //secondIntStack.print();
    //Setting stack equal to the origanal
    //secondIntStack = mystack;
    //cout << "Popping off an element on stack ->" << endl;
    //Pop an element off
    //secondIntStack.pop();
    //Print result
    //secondIntStack.print();

    cout << endl;

    // Checks if stack is empty and the current size
   // cout << "Is the stack empty? " << secondIntStack.IsEmpty()<< " (1 = True, 0 = False)" << endl;
   // cout << "Stack size: " << secondIntStack.GetSize() << endl;
}

//Sets up wrapper function to dump memory leaks
int main()
{
    wrapper();
    _CrtDumpMemoryLeaks();
    getchar();
}