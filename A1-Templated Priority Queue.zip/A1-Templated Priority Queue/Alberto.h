/*----------------------------------------------
Programmer: Alberto Bobadilla (labigm@gmail.com)
Date: 2020/08
----------------------------------------------*/
#ifndef __ALBERTOCLASS_H_
#define __ALBERTOCLASS_H_

#include <iostream>
#include <algorithm>
using namespace std;

//System Class
template <class Placeholder>
class PriorityQueue
{
	//int m_nAge = 36; //Number of elements in the list of elements

public:
	/*
	Usage: Constructor
	Arguments: ---
	Output: class object instance
	*/
	PriorityQueue()
	{
		currentIndex = 0;
		maxSize = 1;
		dataArray = new Placeholder[maxSize];
	};
	/*
	Usage: Constructor with age indicator
	Arguments: Age of this Alberto
	Output: class object instance
	*/
	//PriorityQueue(int a_nAge);
	/*
	Usage: Copy Constructor
	Arguments: class object to copy
	Output: class object instance
	*/
	PriorityQueue(PriorityQueue const& other)
	{
		maxSize = other.maxSize;
		currentIndex = other.currentIndex;
		dataArray = new Placeholder[maxSize];

		copy(other.dataArray, other.dataArray + other.maxSize, dataArray);
	};
	/*
	Usage: Copy Assignment Operator
	Arguments: class object to copy
	Output: ---
	*/
	PriorityQueue& operator=(PriorityQueue const& other)
	{
		if (this == &other)
		{
			return *this;
		}

		if (dataArray != nullptr)
		{
			delete[] dataArray;
			dataArray = nullptr;
			dataArray = 0;
		}

		maxSize = other.maxSize;
		currentIndex = other.currentIndex;
		dataArray = new int[maxSize];

		copy(other.dataArray, other.dataArray + other.maxSize, dataArray);

		return *this;
	};
	/*
	Usage: Destructor
	Arguments: ---
	Output: ---
	*/
	~PriorityQueue()
	{
		delete[] dataArray;
		dataArray = nullptr;
	};


	void push(Placeholder data)
	{
		if (currentIndex >= maxSize) {

			Placeholder* temp = new Placeholder[maxSize * 2];
			copy(dataArray, dataArray + maxSize * 2, temp);

			delete[] dataArray;
			dataArray = nullptr;
			dataArray = temp;
			maxSize = 2 * maxSize;
		}

		dataArray[currentIndex] = data;
		currentIndex++;
	};

	Placeholder pop()
	{
		if (currentIndex < 0) {
			return NULL;
		}
		else
		{
			dataArray[currentIndex];
			currentIndex--;
			return dataArray[currentIndex];
		}
	};

	//Printing results
	void print()
	{
		//for (int i = 0; i < currentIndex; i++)
		//{
			//friend std::ostream& operator<<(std::ostream & os, AlbertoClass other)
			//{
			//	os << other.dataArray[i];
			//	return os;
			//}
		//}

		if (currentIndex < 0)
		{
			cout << "Queue is empty ";
		}
		for (int i = 0; i < currentIndex; i++)
		{
			cout << "Element on Queue: " << dataArray[i] << "  " << endl;
		}
	};


	/*
	Usage: Changes object contents for other object's
	Arguments: other -> object to swap content from
	Output: ---
	*/
	void Swap(PriorityQueue& other);

	/*
	Usage: Larger
	Arguments: class object to verify
	Output: true if this object is larger than other
	*/
	bool operator>(PriorityQueue const& other)
	{

		return this->currentIndex > other.currentIndex;

	};

	/*
	Usage: Smaller
	Arguments: class object to verify
	Output: true if this object is smaller than other
	*/
	bool operator<(PriorityQueue const& other)
	{
		return this->currentIndex < other.currentIndex;
	};

	/*
	Usage: Larger
	Arguments: class object to verify
	Output: true if this object is larger than other
	*/
	bool operator>=(PriorityQueue const& other)
	{

		return this->currentIndex >= other.currentIndex;

	};

	/*
	Usage: Smaller
	Arguments: class object to verify
	Output: true if this object is smaller than other
	*/
	bool operator<=(PriorityQueue const& other)
	{
		return this->currentIndex <= other.currentIndex;
	};


	//Getting the size of the current stack
	int GetSize()
	{
		int sum = 0;
		for (int i = 0; i < currentIndex; i++) {
			return dataArray[i + currentIndex];
		}
		return dataArray[maxSize];
	};

	//Checking if the Queue is empty
	bool IsEmpty()
	{
		if (maxSize == 0) {
			return true;
		}
		else {
			return false;
		}
	};
	/*
	Usage: Gets data member
	Arguments: ---
	Output: data
	*/
	//int GetAge(void);
	/*
	Usage: Sets data member
	Arguments: int a_nData = 1 -> data to set
	Output: ---
	*/
	//void SetAge(int a_nAge);

	//friend std::ostream& operator<<(std::ostream& os, PriorityQueue other)
	//{
	//	os << other.m_nAge;
	//	return os;
	//}

private:
	Placeholder* dataArray;
	int maxSize;
	int currentIndex;
	/*
	Usage: Deallocates member fields
	Arguments: ---
	Output: ---
	*/
	//void Release(void);
	/*
	Usage: Allocates member fields
	Arguments: ---
	Output: ---
	*/
	//void Init(void);
};//class


#endif //__EXAMPLECLASS_H__

/*
USAGE:
ARGUMENTS: ---
OUTPUT: ---
*/